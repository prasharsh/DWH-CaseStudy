-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema caseStudy
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema caseStudy
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `caseStudy` ;
USE `caseStudy` ;

-- -----------------------------------------------------
-- Table `caseStudy`.`T_STATE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_STATE` (
  `STATE_ID` INT NOT NULL AUTO_INCREMENT,
  `STATE_NAME` VARCHAR(45) NULL,
  PRIMARY KEY (`STATE_ID`),
  UNIQUE INDEX `STATE_ID_UNIQUE` (`STATE_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_ADDRESS`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_ADDRESS` (
  `ADDRESS_ID` INT NOT NULL,
  `ADDRESS` VARCHAR(200) NULL,
  PRIMARY KEY (`ADDRESS_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_CITY`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_CITY` (
  `CITY_ID` INT NOT NULL,
  `CITY_NAME` VARCHAR(45) NULL,
  PRIMARY KEY (`CITY_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_POSTAL_CODE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_POSTAL_CODE` (
  `POSTAL_CODE_ID` INT NOT NULL AUTO_INCREMENT,
  `POSTAL_CODE` VARCHAR(45) NULL,
  PRIMARY KEY (`POSTAL_CODE_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_TERRITORY`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_TERRITORY` (
  `TERRITORY_ID` INT NOT NULL AUTO_INCREMENT,
  `TERRITORY_NAME` VARCHAR(45) NULL,
  PRIMARY KEY (`TERRITORY_ID`),
  UNIQUE INDEX `TERRITORY_ID_UNIQUE` (`TERRITORY_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_COUNTRY`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_COUNTRY` (
  `COUNTRY_ID` INT NOT NULL AUTO_INCREMENT,
  `COUNTRY_NAME` VARCHAR(45) NULL,
  PRIMARY KEY (`COUNTRY_ID`),
  UNIQUE INDEX `COUNTRY_ID_UNIQUE` (`COUNTRY_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_LOCATION`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_LOCATION` (
  `LOCATION_ID` INT NOT NULL AUTO_INCREMENT,
  `STATE_ID` INT NOT NULL,
  `ADDRESS_ID` INT NULL,
  `CITY_ID` INT NULL,
  `POSTAL_ID` INT NULL,
  `COUNTRY_ID` INT NULL,
  `TERRITORY_ID` INT NULL,
  PRIMARY KEY (`LOCATION_ID`),
  INDEX `STATE_idx` (`STATE_ID` ASC) VISIBLE,
  INDEX `FK_ADDRESS_idx` (`ADDRESS_ID` ASC) VISIBLE,
  INDEX `FK_CITY_idx` (`CITY_ID` ASC) VISIBLE,
  INDEX `FK_TERRITORY_idx` (`TERRITORY_ID` ASC) VISIBLE,
  INDEX `FK_POSTAL_CODE_idx` (`POSTAL_ID` ASC) VISIBLE,
  INDEX `FK_COUNTRY_idx` (`COUNTRY_ID` ASC) VISIBLE,
  CONSTRAINT `FK_STATE`
    FOREIGN KEY (`STATE_ID`)
    REFERENCES `caseStudy`.`T_STATE` (`STATE_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_ADDRESS`
    FOREIGN KEY (`ADDRESS_ID`)
    REFERENCES `caseStudy`.`T_ADDRESS` (`ADDRESS_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_CITY`
    FOREIGN KEY (`CITY_ID`)
    REFERENCES `caseStudy`.`T_CITY` (`CITY_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_POSTAL_CODE`
    FOREIGN KEY (`POSTAL_ID`)
    REFERENCES `caseStudy`.`T_POSTAL_CODE` (`POSTAL_CODE_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_TERRITORY`
    FOREIGN KEY (`TERRITORY_ID`)
    REFERENCES `caseStudy`.`T_TERRITORY` (`TERRITORY_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_COUNTRY`
    FOREIGN KEY (`COUNTRY_ID`)
    REFERENCES `caseStudy`.`T_COUNTRY` (`COUNTRY_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_TIME`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_TIME` (
  `TIME_ID` INT NOT NULL AUTO_INCREMENT,
  `DAY` VARCHAR(20) NULL,
  `MONTH` INT NULL,
  `QUARTER` INT NULL,
  `YEAR` INT NULL,
  PRIMARY KEY (`TIME_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_CONTACT_PERSON`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_CONTACT_PERSON` (
  `CONTACT_PERSON_ID` INT NOT NULL AUTO_INCREMENT,
  `FIRST_NAME` VARCHAR(45) NULL,
  `LAST_NAME` VARCHAR(45) NULL,
  PRIMARY KEY (`CONTACT_PERSON_ID`),
  UNIQUE INDEX `CONTACT_PERSON_ID_UNIQUE` (`CONTACT_PERSON_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_CUSTOMER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_CUSTOMER` (
  `CUSTOMER_ID` INT NOT NULL AUTO_INCREMENT,
  `CUSTOMER_NAME` VARCHAR(45) NULL,
  `PHONE` VARCHAR(45) NULL,
  PRIMARY KEY (`CUSTOMER_ID`),
  UNIQUE INDEX `CUSTOMER_ID_UNIQUE` (`CUSTOMER_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_ORDER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_ORDER` (
  `ORDER_ID` INT NOT NULL,
  `STATUS` VARCHAR(45) NULL,
  PRIMARY KEY (`ORDER_ID`),
  UNIQUE INDEX `ORDER_ID_UNIQUE` (`ORDER_ID` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_PRODUCT`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_PRODUCT` (
  `PRODUCT_CODE` INT NOT NULL,
  `PRODUCT_LINE` VARCHAR(45) NULL,
  `MSRP` DECIMAL(6,2) NULL,
  `PRODUCT` VARCHAR(45) NULL,
  PRIMARY KEY (`PRODUCT_CODE`),
  UNIQUE INDEX `PRODUCT_CODE` (`PRODUCT_CODE` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_ORDERLINE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_ORDERLINE` (
  `ORDERLINE_ID` INT NOT NULL,
  `ORDER_ID` INT NOT NULL,
  `ORDERLINE` INT NULL,
  `DEAL_SIZE` VARCHAR(45) NULL,
  PRIMARY KEY (`ORDERLINE_ID`),
  UNIQUE INDEX `ORDERLINE_ID_UNIQUE` (`ORDERLINE_ID` ASC) VISIBLE,
  INDEX `ORDER_idx` (`ORDER_ID` ASC) VISIBLE,
  CONSTRAINT `FK_ORDERLINE_ORDER`
    FOREIGN KEY (`ORDER_ID`)
    REFERENCES `caseStudy`.`T_ORDER` (`ORDER_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `caseStudy`.`T_PRODUCT_SALES`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `caseStudy`.`T_PRODUCT_SALES` (
  `PRODUCT_CODE` INT NOT NULL,
  `ORDERLINE_ID` INT NOT NULL,
  `ORDER_ID` INT NOT NULL,
  `TIME_ID` INT NOT NULL,
  `LOCATION_ID` INT NOT NULL,
  `CUSTOMER_ID` INT NOT NULL,
  `CONTACT_PERSON_ID` INT NOT NULL,
  `SALES` DECIMAL(6,2) NULL,
  `PRICE_EACH` DECIMAL(6,2) NULL,
  `QUANTITY` INT NULL,
  PRIMARY KEY (`PRODUCT_CODE`, `ORDERLINE_ID`, `ORDER_ID`, `TIME_ID`, `LOCATION_ID`, `CUSTOMER_ID`, `CONTACT_PERSON_ID`),
  INDEX `CITY_idx` (`LOCATION_ID` ASC) VISIBLE,
  INDEX `TIME_idx` (`TIME_ID` ASC) VISIBLE,
  INDEX `CONTACT_PERSON_idx` (`CONTACT_PERSON_ID` ASC) VISIBLE,
  INDEX `CUSTOMER_idx` (`CUSTOMER_ID` ASC) VISIBLE,
  INDEX `ORDERS_idx` (`ORDER_ID` ASC) VISIBLE,
  INDEX `ORDERLINE_idx` (`ORDERLINE_ID` ASC) VISIBLE,
  CONSTRAINT `FK_LOCATION`
    FOREIGN KEY (`LOCATION_ID`)
    REFERENCES `caseStudy`.`T_LOCATION` (`LOCATION_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_TIME`
    FOREIGN KEY (`TIME_ID`)
    REFERENCES `caseStudy`.`T_TIME` (`TIME_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_CONTACT_PERSON`
    FOREIGN KEY (`CONTACT_PERSON_ID`)
    REFERENCES `caseStudy`.`T_CONTACT_PERSON` (`CONTACT_PERSON_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_CUSTOMER`
    FOREIGN KEY (`CUSTOMER_ID`)
    REFERENCES `caseStudy`.`T_CUSTOMER` (`CUSTOMER_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDERS`
    FOREIGN KEY (`ORDER_ID`)
    REFERENCES `caseStudy`.`T_ORDER` (`ORDER_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_PRODUCT`
    FOREIGN KEY (`PRODUCT_CODE`)
    REFERENCES `caseStudy`.`T_PRODUCT` (`PRODUCT_CODE`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDERLINE`
    FOREIGN KEY (`ORDERLINE_ID`)
    REFERENCES `caseStudy`.`T_ORDERLINE` (`ORDERLINE_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
